import os
import json
import logging
import uuid
import base64
import cgi
import io
import urllib.parse
from datetime import datetime
from typing import Dict, Any, Optional, List

import boto3
from botocore.exceptions import ClientError

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# AWS 服務初始化
dynamodb = boto3.resource('dynamodb', region_name='ap-southeast-1')
s3 = boto3.client('s3', region_name='ap-southeast-1')

# 環境變數
TEAMS_TABLE_NAME = os.environ.get('TEAMS_TABLE_NAME', 'benson-haire-teams')
BACKUP_S3_BUCKET = os.environ.get('BACKUP_S3_BUCKET', '')
TEAM_INFO_BUCKET = os.environ.get('TEAM_INFO_BUCKET', 'benson-haire-team-info-e36d5aee')

# DynamoDB Table
teams_table = dynamodb.Table(TEAMS_TABLE_NAME)

# S3 檔案管理設定 - 統一使用新的資料夾結構
S3_FOLDER_PREFIX = 'team_info_docs'

def lambda_handler(event, context):
    """主要 Lambda 處理函式"""
    logger.info(f"🔥🔥🔥 Lambda 函數被調用! Event: {json.dumps(event, default=str)}")
    
    # 設置 CORS 響應頭
    headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-Amz-Date, X-Api-Key, X-Amz-Security-Token',
        'Content-Type': 'application/json'
    }
    
    try:
        # 處理 OPTIONS 請求 (CORS preflight)
        if event.get('httpMethod') == 'OPTIONS':
            logger.info("🔥 處理 OPTIONS 請求")
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'message': 'CORS preflight successful'})
            }
        
        # 取得請求方法和路徑
        method = event.get('httpMethod', '')
        path = event.get('path', '')
        path_parameters = event.get('pathParameters') or {}
        query_parameters = event.get('queryStringParameters') or {}
        
        logger.info(f"📨 收到請求: {method} {path}")
        logger.info(f"🔍 路徑參數: {path_parameters}")
        logger.info(f"🔍 查詢參數: {query_parameters}")
        
        # 改善路由處理邏輯
        # 團隊管理 API
        if method == 'GET' and path == '/teams':
            logger.info("🏢 路由到：列出所有團隊")
            return list_teams(event, headers)
        elif method == 'POST' and path == '/teams':
            logger.info("🏢 路由到：創建新團隊")
            return create_team(event, headers)
        elif method == 'GET' and '/teams/' in path and path_parameters.get('team_id'):
            team_id = path_parameters.get('team_id')
            query_params = event.get('queryStringParameters') or {}
            action = query_params.get('action', '')
            
            # 檢查是否是檔案相關的查詢
            if action == 'files':
                logger.info(f"📂 路由到：列出團隊檔案 {team_id}")
                return handle_list_files(event, headers)
            # 檢查是否是檔案相關的子路由
            elif path.endswith('/files'):
                logger.info(f"📂 路由到：列出團隊檔案 {team_id}")
                return handle_list_files(event, headers)
            else:
                logger.info(f"🏢 路由到：取得團隊 {team_id}")
                return get_team(event, headers)
        elif method == 'PUT' and '/teams/' in path and path_parameters.get('team_id'):
            logger.info(f"🏢 路由到：更新團隊 {path_parameters['team_id']}")
            return update_team(event, headers)
        elif method == 'DELETE' and '/teams/' in path and path_parameters.get('team_id'):
            logger.info(f"🏢 路由到：刪除團隊 {path_parameters['team_id']}")
            return delete_team(event, headers)
        
        # 檔案上傳路由 - 添加調試日誌
        logger.info(f"🔍 檢查檔案上傳條件: method={method}, path={path}, team_id={path_parameters.get('team_id')}, endswith_files={path.endswith('/files')}")
        
        if method == 'POST' and '/teams/' in path and path_parameters.get('team_id') and path.endswith('/files'):
            logger.info(f"📤 路由到：上傳團隊檔案 {path_parameters['team_id']}")
            return handle_file_upload(event, headers)
        
        # 檔案管理 API
        elif method == 'GET' and '/team-files/' in path:
            logger.info("📂 路由到：檔案列表")
            return handle_list_files(event, headers)
        elif method == 'GET' and '/download-team-file/' in path:
            logger.info("📥 路由到：檔案下載")
            return handle_file_download(event, headers)
        elif method == 'DELETE' and '/delete-team-file' in path:
            logger.info("🗑️ 路由到：檔案刪除")
            return handle_file_delete(event, headers)
        
        else:
            logger.warning(f"⚠️ 未匹配的路由: {method} {path}")
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({
                    'error': '找不到對應的 API 端點',
                    'method': method,
                    'path': path,
                    'available_endpoints': {
                        'teams': {
                            'GET /teams': '列出所有團隊',
                            'POST /teams': '創建新團隊',
                            'GET /teams/{team_id}': '取得特定團隊',
                            'PUT /teams/{team_id}': '更新團隊',
                            'DELETE /teams/{team_id}': '刪除團隊'
                        },
                        'files': {
                            'POST /teams/{team_id}/files': '上傳檔案',
                            'GET /team-files/{team_id}': '列出團隊檔案',
                            'GET /download-team-file/{file_key}': '下載檔案',
                            'DELETE /delete-team-file': '刪除檔案'
                        }
                    }
                })
            }
            
    except Exception as e:
        logger.error(f"❌ Lambda 函數執行錯誤: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '伺服器內部錯誤',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }

def list_teams(event, headers):
    """列出所有團隊"""
    try:
        logger.info("🏢 開始列出所有團隊")
        response = teams_table.scan()
        teams = response.get('Items', [])
        
        logger.info(f"✅ 成功取得 {len(teams)} 個團隊")
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'teams': teams,
                'count': len(teams),
                'timestamp': datetime.now().isoformat()
            }, default=str)
        }
    except Exception as e:
        logger.error(f"❌ 列出團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '列出團隊失敗',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }

def get_team(event, headers):
    """取得特定團隊資訊 - 同時從 DynamoDB 和 S3 讀取"""
    try:
        path_parameters = event.get('pathParameters') or {}
        team_id = path_parameters.get('team_id')
        
        if not team_id:
            logger.warning("⚠️ 缺少 team_id 路徑參數")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '缺少團隊 ID',
                    'message': '請在路徑參數中提供 team_id'
                })
            }
        
        logger.info(f"🏢 開始取得團隊資訊: {team_id}")
        
        # 從 DynamoDB 取得基本團隊資訊
        response = teams_table.get_item(Key={'team_id': team_id})
        
        if 'Item' not in response:
            logger.warning(f"⚠️ 找不到團隊: {team_id}")
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({
                    'error': '找不到指定的團隊',
                    'team_id': team_id
                })
            }
        
        team_data = response['Item']
        
        # 嘗試從 S3 讀取額外的團隊資訊檔案
        try:
            s3_key = f'{S3_FOLDER_PREFIX}/{team_id}/team_info.json'
            logger.info(f"📄 嘗試讀取 S3 團隊資訊: {s3_key}")
            
            s3_response = s3.get_object(
                Bucket=TEAM_INFO_BUCKET,
                Key=s3_key
            )
            
            s3_data = json.loads(s3_response['Body'].read().decode('utf-8'))
            logger.info(f"✅ 成功從 S3 讀取團隊資訊")
            
            # 合併 S3 資料（S3 資料優先，但保留 DynamoDB 的更新時間）
            for key, value in s3_data.items():
                if key not in ['updated_at']:  # 保留 DynamoDB 的更新時間
                    team_data[key] = value
                    
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                logger.info(f"📄 S3 中沒有額外的團隊資訊檔案: {s3_key}")
            else:
                logger.warning(f"⚠️ 讀取 S3 團隊資訊時發生錯誤: {str(e)}")
        except Exception as e:
            logger.warning(f"⚠️ 處理 S3 團隊資訊時發生錯誤: {str(e)}")
        
        # 取得團隊檔案列表
        try:
            s3_prefix = f'{S3_FOLDER_PREFIX}/{team_id}/'
            files_response = s3.list_objects_v2(
                Bucket=TEAM_INFO_BUCKET,
                Prefix=s3_prefix
            )
            
            files = []
            if 'Contents' in files_response:
                for obj in files_response['Contents']:
                    # 從完整的 S3 Key 中提取原始檔案名稱
                    original_filename = obj['Key'].replace(s3_prefix, '', 1)
                    
                    # 跳過資料夾本身和 team_info.json
                    if (original_filename and 
                        not original_filename.endswith('/') and 
                        original_filename != 'team_info.json'):
                        file_info = {
                            'key': obj['Key'],
                            'name': original_filename,
                            'size': obj['Size'],
                            'lastModified': obj['LastModified'].isoformat(),
                            'etag': obj['ETag'].strip('"')
                        }
                        files.append(file_info)
            
            team_data['files'] = files
            team_data['file_count'] = len(files)
            logger.info(f"📂 團隊檔案數量: {len(files)}")
            
        except Exception as e:
            logger.warning(f"⚠️ 取得團隊檔案列表時發生錯誤: {str(e)}")
            team_data['files'] = []
            team_data['file_count'] = 0
        
        logger.info(f"✅ 成功取得團隊資訊: {team_id}")
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'team': team_data,
                'timestamp': datetime.now().isoformat()
            }, default=str)
        }
    except Exception as e:
        logger.error(f"❌ 取得團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '取得團隊失敗',
                'message': str(e),
                'team_id': team_id if 'team_id' in locals() else 'unknown',
                'timestamp': datetime.now().isoformat()
            })
        }

def create_team(event, headers):
    """建立新團隊（支援檔案上傳）"""
    try:
        logger.info("🏢 開始創建新團隊")
        content_type = event.get('headers', {}).get('content-type', 
                      event.get('headers', {}).get('Content-Type', ''))
        
        logger.info(f"📝 Content-Type: {content_type}")
        
        if 'multipart/form-data' in content_type:
            # 處理包含檔案的請求
            logger.info("📤 處理包含檔案的團隊創建請求")
            return create_team_with_files(event, headers)
        else:
            # 處理純 JSON 請求
            logger.info("📝 處理純 JSON 團隊創建請求")
            try:
                body = json.loads(event.get('body', '{}'))
                logger.info(f"📝 解析的請求體: {body}")
                return create_team_json(body, headers)
            except json.JSONDecodeError as e:
                logger.error(f"❌ JSON 解析失敗: {str(e)}")
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({
                        'error': 'JSON 格式錯誤',
                        'message': str(e),
                        'received_body': event.get('body', '')[:200]  # 只顯示前200個字符
                    })
                }
            
    except Exception as e:
        logger.error(f"❌ 建立團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '建立團隊失敗',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }

def create_team_json(team_data, headers):
    """建立團隊（純 JSON 模式）"""
    try:
        logger.info(f"🏢 建立團隊 - 收到資料: {team_data}")
        
        # 欄位映射 - 支援前端的欄位名稱
        field_mapping = {
            'dept_code': 'department_code',
            'team_code': 'section_code', 
            'team_description': 'description'
        }
        
        # 建立標準化的團隊資料
        normalized_data = {}
        
        # 複製並映射欄位
        for key, value in team_data.items():
            if key in field_mapping:
                # 使用映射後的欄位名
                normalized_data[field_mapping[key]] = value
                logger.info(f"🔄 欄位映射: {key} -> {field_mapping[key]} = {value}")
            else:
                # 直接使用原欄位名
                normalized_data[key] = value
        
        logger.info(f"🏢 標準化後的資料: {normalized_data}")
        
        # 驗證必要欄位
        required_fields = ['company_code', 'department_code', 'section_code', 'team_name']
        missing_fields = []
        
        for field in required_fields:
            if field not in normalized_data or not normalized_data[field]:
                missing_fields.append(field)
        
        if missing_fields:
            logger.error(f"❌ 缺少必要欄位: {missing_fields}")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': f'缺少必要欄位: {", ".join(missing_fields)}',
                    'missing_fields': missing_fields,
                    'received_data': team_data,
                    'normalized_data': normalized_data
                })
            }
        
        # 建立團隊 ID
        team_id = f"{normalized_data['company_code']}-{normalized_data['department_code']}-{normalized_data['section_code']}"
        logger.info(f"🏢 生成團隊 ID: {team_id}")
        
        # 檢查團隊是否已存在
        existing_team = teams_table.get_item(Key={'team_id': team_id})
        if 'Item' in existing_team:
            logger.warning(f"⚠️ 團隊已存在: {team_id}")
            return {
                'statusCode': 409,
                'headers': headers,
                'body': json.dumps({
                    'error': '團隊已存在',
                    'existing_team_id': team_id
                })
            }
        
        # 建立團隊資料
        team_item = {
            'team_id': team_id,
            'company_code': normalized_data['company_code'],
            'department_code': normalized_data['department_code'], 
            'section_code': normalized_data['section_code'],
            'team_name': normalized_data['team_name'],
            'description': normalized_data.get('description', ''),
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        # 保留前端的額外欄位以便顯示
        if 'company' in team_data:
            team_item['company'] = team_data['company']
        if 'department' in team_data:
            team_item['department'] = team_data['department']
        
        logger.info(f"💾 準備儲存團隊資料: {team_item}")
        
        # 儲存到 DynamoDB
        teams_table.put_item(Item=team_item)
        logger.info(f"✅ 團隊已儲存到 DynamoDB: {team_id}")
        
        # 備份到 S3
        backup_team_to_s3(team_item)
        
        # 創建團隊檔案資料夾
        create_team_folder(team_id)
        
        logger.info(f"🎉 團隊建立成功: {team_id}")
        return {
            'statusCode': 201,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'team': team_item,
                'team_id': team_id,  # 添加 team_id 給前端使用
                'message': '團隊建立成功',
                'timestamp': datetime.now().isoformat()
            }, default=str)
        }
        
    except Exception as e:
        logger.error(f"❌ 建立團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise

def create_team_with_files(event, headers):
    """建立團隊（支援檔案上傳）"""
    try:
        # 解析 multipart/form-data
        content_type = event.get('headers', {}).get('content-type', 
                      event.get('headers', {}).get('Content-Type', ''))
        body_bytes = base64.b64decode(event['body']) if event.get('isBase64Encoded', False) else event['body'].encode('utf-8')
        
        fp = io.BytesIO(body_bytes)
        environ = {'REQUEST_METHOD': 'POST'}
        
        form = cgi.FieldStorage(fp=fp, environ=environ, headers={'content-type': content_type})
        
        # 提取團隊資料
        team_data = {}
        for field_name in ['company_code', 'department_code', 'section_code', 'team_name', 'description']:
            if field_name in form:
                team_data[field_name] = form[field_name].value
        
        # 驗證必要欄位
        required_fields = ['company_code', 'department_code', 'section_code', 'team_name']
        for field in required_fields:
            if field not in team_data:
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({'error': f'缺少必要欄位: {field}'})
                }
        
        # 建立團隊
        team_id = f"{team_data['company_code']}-{team_data['department_code']}-{team_data['section_code']}"
        
        # 檢查團隊是否已存在
        existing_team = teams_table.get_item(Key={'team_id': team_id})
        if 'Item' in existing_team:
            return {
                'statusCode': 409,
                'headers': headers,
                'body': json.dumps({'error': '團隊已存在'})
            }
        
        # 建立團隊資料
        team_item = {
            'team_id': team_id,
            'company_code': team_data['company_code'],
            'department_code': team_data['department_code'],
            'section_code': team_data['section_code'],
            'team_name': team_data['team_name'],
            'description': team_data.get('description', ''),
            'created_at': datetime.now().isoformat(),
            'updated_at': datetime.now().isoformat()
        }
        
        # 儲存到 DynamoDB
        teams_table.put_item(Item=team_item)
        
        # 備份到 S3
        backup_team_to_s3(team_item)
        
        # 處理檔案上傳
        uploaded_files = []
        if 'files' in form:
            file_items = form['files'] if isinstance(form['files'], list) else [form['files']]
            for file_item in file_items:
                if file_item.filename:
                    uploaded_file_info = upload_team_file(team_id, file_item)
                    uploaded_files.append(uploaded_file_info)
        
        team_item['uploaded_files'] = uploaded_files
        
        return {
            'statusCode': 201,
            'headers': headers,
            'body': json.dumps(team_item, default=str)
        }
        
    except Exception as e:
        logger.error(f"❌ 建立團隊（含檔案）失敗: {str(e)}")
        raise

def update_team(event, headers):
    """更新團隊（支援檔案上傳）"""
    try:
        path_parameters = event.get('pathParameters') or {}
        team_id = path_parameters.get('team_id')
        
        if not team_id:
            logger.warning("⚠️ 缺少 team_id 路徑參數")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '缺少團隊 ID',
                    'message': '請在路徑參數中提供 team_id'
                })
            }
        
        logger.info(f"🏢 開始更新團隊: {team_id}")
        content_type = event.get('headers', {}).get('content-type', 
                      event.get('headers', {}).get('Content-Type', ''))
        
        if 'multipart/form-data' in content_type:
            # 處理包含檔案的請求
            logger.info("📤 處理包含檔案的團隊更新請求")
            return update_team_with_files(event, headers, team_id)
        else:
            # 處理純 JSON 請求
            logger.info("📝 處理純 JSON 團隊更新請求")
            try:
                body = json.loads(event.get('body', '{}'))
                return update_team_json(body, headers, team_id)
            except json.JSONDecodeError as e:
                logger.error(f"❌ JSON 解析失敗: {str(e)}")
                return {
                    'statusCode': 400,
                    'headers': headers,
                    'body': json.dumps({
                        'error': 'JSON 格式錯誤',
                        'message': str(e)
                    })
                }
            
    except Exception as e:
        logger.error(f"❌ 更新團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '更新團隊失敗',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }

def update_team_json(team_data, headers, team_id):
    """更新團隊（純 JSON 模式）"""
    try:
        logger.info(f"🏢 更新團隊 {team_id} - 收到資料: {team_data}")
        
        # 檢查團隊是否存在
        existing_team = teams_table.get_item(Key={'team_id': team_id})
        if 'Item' not in existing_team:
            logger.warning(f"⚠️ 團隊不存在: {team_id}")
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({
                    'error': '團隊不存在',
                    'team_id': team_id
                })
            }
        
        current_team = existing_team['Item']
        
        # 欄位映射
        field_mapping = {
            'team_description': 'description'
        }
        
        # 建立更新的欄位
        update_fields = {}
        for key, value in team_data.items():
            if key in field_mapping:
                update_fields[field_mapping[key]] = value
            elif key in ['company', 'department', 'team_name', 'description']:
                # 只允許更新這些欄位，不允許更新會影響 team_id 的 code 欄位
                update_fields[key] = value
        
        # 設定更新時間
        update_fields['updated_at'] = datetime.now().isoformat()
        
        logger.info(f"📝 準備更新欄位: {update_fields}")
        
        # 準備更新表達式
        update_expression = "SET "
        expression_attribute_values = {}
        
        for field, value in update_fields.items():
            if update_expression != "SET ":
                update_expression += ", "
            update_expression += f"{field} = :{field}"
            expression_attribute_values[f":{field}"] = value
        
        # 執行更新
        response = teams_table.update_item(
            Key={'team_id': team_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_attribute_values,
            ReturnValues='ALL_NEW'
        )
        
        updated_team = response['Attributes']
        logger.info(f"✅ 團隊更新成功: {team_id}")
        
        # 備份到 S3
        backup_team_to_s3(updated_team)
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'team': updated_team,
                'team_id': team_id,  # 添加 team_id 給前端使用
                'message': '團隊更新成功',
                'timestamp': datetime.now().isoformat()
            }, default=str)
        }
        
    except Exception as e:
        logger.error(f"❌ 更新團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        raise

def update_team_with_files(event, headers, team_id):
    """更新團隊（支援檔案上傳）"""
    try:
        # 檢查團隊是否存在
        existing_team = teams_table.get_item(Key={'team_id': team_id})
        if 'Item' not in existing_team:
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({'error': '找不到指定的團隊'})
            }
        
        # 解析 multipart/form-data
        content_type = event.get('headers', {}).get('content-type', 
                      event.get('headers', {}).get('Content-Type', ''))
        body_bytes = base64.b64decode(event['body']) if event.get('isBase64Encoded', False) else event['body'].encode('utf-8')
        
        fp = io.BytesIO(body_bytes)
        environ = {'REQUEST_METHOD': 'POST'}
        
        form = cgi.FieldStorage(fp=fp, environ=environ, headers={'content-type': content_type})
        
        # 更新團隊資料
        update_expression = "SET updated_at = :updated_at"
        expression_values = {':updated_at': datetime.now().isoformat()}
        
        for field in ['team_name', 'description']:
            if field in form:
                update_expression += f", {field} = :{field}"
                expression_values[f':{field}'] = form[field].value
        
        teams_table.update_item(
            Key={'team_id': team_id},
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_values
        )
        
        # 處理檔案上傳
        uploaded_files = []
        if 'files' in form:
            file_items = form['files'] if isinstance(form['files'], list) else [form['files']]
            for file_item in file_items:
                if file_item.filename:
                    uploaded_file_info = upload_team_file(team_id, file_item)
                    uploaded_files.append(uploaded_file_info)
        
        # 取得更新後的團隊資料
        updated_team = teams_table.get_item(Key={'team_id': team_id})['Item']
        
        # 備份到 S3
        backup_team_to_s3(updated_team)
        
        updated_team['uploaded_files'] = uploaded_files
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps(updated_team, default=str)
        }
        
    except Exception as e:
        logger.error(f"❌ 更新團隊（含檔案）失敗: {str(e)}")
        raise

def delete_team(event, headers):
    """刪除團隊"""
    try:
        path_parameters = event.get('pathParameters') or {}
        team_id = path_parameters.get('team_id')
        
        if not team_id:
            logger.warning("⚠️ 缺少 team_id 路徑參數")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '缺少團隊 ID',
                    'message': '請在路徑參數中提供 team_id'
                })
            }
        
        logger.info(f"🏢 開始刪除團隊: {team_id}")
        
        # 檢查團隊是否存在
        existing_team = teams_table.get_item(Key={'team_id': team_id})
        if 'Item' not in existing_team:
            logger.warning(f"⚠️ 找不到團隊: {team_id}")
            return {
                'statusCode': 404,
                'headers': headers,
                'body': json.dumps({
                    'error': '找不到指定的團隊',
                    'team_id': team_id
                })
            }
        
        # 從 DynamoDB 刪除
        teams_table.delete_item(Key={'team_id': team_id})
        logger.info(f"✅ 從 DynamoDB 刪除團隊: {team_id}")
        
        # 從 S3 刪除備份檔案
        try:
            s3.delete_object(Bucket=TEAM_INFO_BUCKET, Key=f'{S3_FOLDER_PREFIX}/{team_id}/team_info.json')
            logger.info(f"✅ 從 S3 刪除備份檔案: {S3_FOLDER_PREFIX}/{team_id}/team_info.json")
        except ClientError as e:
            logger.warning(f"⚠️ 刪除 S3 備份檔案失敗: {str(e)}")
        
        # 可選擇是否刪除團隊相關的所有檔案
        # TODO: 實作刪除團隊檔案功能 (需要確認是否要刪除 team_info_docs/{team_id}/ 下的所有檔案)
        
        logger.info(f"✅ 團隊刪除成功: {team_id}")
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'message': '團隊刪除成功',
                'team_id': team_id,
                'timestamp': datetime.now().isoformat()
            })
        }
        
    except Exception as e:
        logger.error(f"❌ 刪除團隊失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '刪除團隊失敗',
                'message': str(e),
                'team_id': team_id if 'team_id' in locals() else 'unknown',
                'timestamp': datetime.now().isoformat()
            })
        }

def upload_team_file(team_id, file_item):
    """上傳團隊檔案到 S3"""
    try:
        original_filename = file_item.filename
        file_content = file_item.file.read()
        
        # 清理檔案名稱
        safe_filename = "".join(c if c.isalnum() or c in ('.', '_', '-') else '_' for c in original_filename)
        
        # 建構 S3 金鑰
        s3_key = f"{S3_FOLDER_PREFIX}/{team_id}/{safe_filename}"
        
        # 上傳到 S3
        s3.put_object(
            Bucket=TEAM_INFO_BUCKET,
            Key=s3_key,
            Body=file_content,
            ContentType=file_item.type or 'application/octet-stream'
        )
        
        logger.info(f"✅ 檔案上傳成功: s3://{TEAM_INFO_BUCKET}/{s3_key}")
        
        return {
            'key': s3_key,
            'filename': original_filename,
            'size': len(file_content)
        }
        
    except Exception as e:
        logger.error(f"❌ 檔案上傳失敗: {str(e)}")
        raise

def backup_team_to_s3(team_data):
    """備份團隊資料到 S3 - 使用新的檔案結構"""
    try:
        team_id = team_data['team_id']
        s3_key = f'{S3_FOLDER_PREFIX}/{team_id}/team_info.json'
        
        s3.put_object(
            Bucket=TEAM_INFO_BUCKET,
            Key=s3_key,
            Body=json.dumps(team_data, default=str),
            ContentType='application/json'
        )
        
        logger.info(f"✅ 團隊資料備份成功: s3://{TEAM_INFO_BUCKET}/{s3_key}")
        
    except Exception as e:
        logger.error(f"❌ 團隊資料備份失敗: {str(e)}")
        # 不拋出例外，因為備份失敗不應該影響主要功能

def create_team_folder(team_id):
    """創建團隊檔案資料夾"""
    try:
        s3.put_object(
            Bucket=TEAM_INFO_BUCKET,
            Key=f'{S3_FOLDER_PREFIX}/{team_id}/'
        )
        logger.info(f"✅ 團隊檔案資料夾創建成功: s3://{TEAM_INFO_BUCKET}/{S3_FOLDER_PREFIX}/{team_id}/")
    except Exception as e:
        logger.error(f"❌ 創建團隊檔案資料夾失敗: {str(e)}")
        # 不拋出例外，因為資料夾創建失敗不應該影響主要功能

# === 檔案管理功能 ===

def handle_file_upload(event: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
    """處理檔案上傳"""
    try:
        content_type_header = event.get('headers', {}).get('content-type', event.get('headers', {}).get('Content-Type', ''))
        
        if not content_type_header or 'multipart/form-data' not in content_type_header:
            logger.warning(f"⚠️ 錯誤的 Content-Type: {content_type_header}")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': '需要 multipart/form-data 格式'})
            }

        # 支援多種方式取得 team_id
        path_params = event.get('pathParameters') or {}
        query_params = event.get('queryStringParameters') or {}
        
        team_id = (
            path_params.get('team_id') or 
            query_params.get('teamId') or 
            query_params.get('team_id') or
            ''
        )
        
        if not team_id:
            logger.warning("⚠️ 缺少 teamId 參數")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '缺少 teamId 參數',
                    'message': '請在路徑參數或查詢參數中提供 teamId',
                    'received_params': {
                        'pathParameters': path_params,
                        'queryStringParameters': query_params
                    }
                })
            }

        # 解碼 base64 主體
        body_bytes = base64.b64decode(event['body']) if event.get('isBase64Encoded', False) else event['body'].encode('utf-8')
        
        # 使用 cgi.FieldStorage 解析 multipart/form-data
        fp = io.BytesIO(body_bytes)
        environ = {'REQUEST_METHOD': 'POST'}
        
        if isinstance(content_type_header, bytes):
            content_type_header = content_type_header.decode('utf-8')

        form = cgi.FieldStorage(fp=fp, environ=environ, headers={'content-type': content_type_header})

        uploaded_files_info = []

        if 'file' in form:
            file_item = form['file']
            if isinstance(file_item, list):
                file_items = file_item
            else:
                file_items = [file_item]

            for item in file_items:
                if item.filename:
                    original_filename = item.filename
                    file_content = item.file.read()
                    
                    # 清理檔案名稱
                    safe_original_filename = "".join(c if c.isalnum() or c in ('.', '_', '-') else '_' for c in original_filename)
                    file_key = f"{S3_FOLDER_PREFIX}/{team_id}/{safe_original_filename}"
                    
                    # 上傳到 S3
                    s3.put_object(
                        Bucket=TEAM_INFO_BUCKET,
                        Key=file_key,
                        Body=file_content,
                    )
                    
                    logger.info(f"✅ 檔案上傳成功: s3://{TEAM_INFO_BUCKET}/{file_key}")
                    uploaded_files_info.append({
                        'key': file_key,
                        'filename': original_filename,
                        'size': len(file_content)
                    })
                else:
                    logger.warning("⚠️ 收到一個沒有檔案名稱的 file item")
        else:
            logger.warning("⚠️ multipart/form-data 中沒有找到 'file' 欄位")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': "multipart/form-data 中沒有找到 'file' 欄位"})
            }

        if not uploaded_files_info:
             logger.warning("⚠️ 沒有成功上傳任何檔案")
             return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({'error': '沒有成功上傳任何檔案'})
            }
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'message': f'{len(uploaded_files_info)} 個檔案上傳成功',
                'uploaded_files': uploaded_files_info
            })
        }
        
    except Exception as e:
        logger.error(f"❌ 檔案上傳失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '檔案上傳失敗',
                'message': str(e)
            })
        }

def handle_list_files(event: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
    """列出團隊檔案 - 統一使用 team_info_docs/{team_id}/ 格式"""
    logger.info("🔥 進入 handle_list_files 函數")
    try:
        # 支援多種參數取得方式
        path_params = event.get('pathParameters') or {}
        query_params = event.get('queryStringParameters') or {}
        path = event.get('path', '')
        
        # 嘗試從路徑參數或查詢參數取得 team_id
        team_id = (
            path_params.get('team_id') or 
            query_params.get('team_id') or 
            query_params.get('teamId') or 
            ''
        )
        
        # 如果還沒有找到 team_id，嘗試從 URL 路徑中解析
        if not team_id and '/team-files/' in path:
            # 從 /team-files/{team_id} 格式中解析
            parts = path.split('/team-files/')
            if len(parts) > 1 and parts[1]:
                team_id = parts[1].strip('/')
                logger.info(f"📂 從路徑解析 team_id: {team_id}")
        
        logger.info(f"📂 解析參數: path={path}, path_params={path_params}, query_params={query_params}, team_id={team_id}")
        
        if not team_id:
            logger.warning("⚠️ 缺少 team_id 參數")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '缺少團隊 ID',
                    'message': '請在路徑參數或查詢參數中提供 team_id',
                    'received_params': {
                        'path': path,
                        'pathParameters': path_params,
                        'queryStringParameters': query_params
                    }
                })
            }
        
        logger.info(f"📂 開始列出檔案，team_id: {team_id}, bucket: {TEAM_INFO_BUCKET}")
        
        files = []
        
        # 使用統一的新格式 (資料夾結構): team_info_docs/{team_id}/
        try:
            s3_prefix = f'{S3_FOLDER_PREFIX}/{team_id}/'
            logger.info(f"🔍 檢查檔案，prefix: {s3_prefix}")
            
            response = s3.list_objects_v2(
                Bucket=TEAM_INFO_BUCKET,
                Prefix=s3_prefix
            )
            
            logger.info(f"📋 S3 回應 KeyCount: {response.get('KeyCount', 0)}")
            
            if 'Contents' in response:
                for obj in response['Contents']:
                    # 從完整的 S3 Key 中提取原始檔案名稱
                    original_filename = obj['Key'].replace(s3_prefix, '', 1)
                    
                    # 跳過資料夾本身（如果有的話）
                    if original_filename and not original_filename.endswith('/'):
                        file_info = {
                            'key': obj['Key'],
                            'name': original_filename,
                            'size': obj['Size'],
                            'lastModified': obj['LastModified'].isoformat(),
                            'etag': obj['ETag'].strip('"')
                        }
                        files.append(file_info)
                        logger.info(f"✅ 找到檔案: {original_filename}")
            else:
                logger.info(f"📁 資料夾為空: {s3_prefix}")
                
        except ClientError as e:
            error_code = e.response['Error']['Code']
            if error_code == 'NoSuchBucket':
                logger.error(f"❌ S3 Bucket 不存在: {TEAM_INFO_BUCKET}")
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({
                        'error': f'S3 Bucket {TEAM_INFO_BUCKET} 不存在',
                        'bucket': TEAM_INFO_BUCKET,
                        'timestamp': datetime.now().isoformat()
                    })
                }
            else:
                logger.error(f"❌ S3 錯誤: {str(e)}")
                return {
                    'statusCode': 500,
                    'headers': headers,
                    'body': json.dumps({
                        'error': 'S3 存取錯誤',
                        'message': str(e),
                        'bucket': TEAM_INFO_BUCKET,
                        'prefix': s3_prefix,
                        'timestamp': datetime.now().isoformat()
                    })
                }
        except Exception as e:
            logger.error(f"❌ 列出檔案時發生錯誤: {str(e)}")
            import traceback
            logger.error(traceback.format_exc())
            return {
                'statusCode': 500,
                'headers': headers,
                'body': json.dumps({
                    'error': '列出檔案失敗',
                    'message': str(e),
                    'timestamp': datetime.now().isoformat()
                })
            }
        
        logger.info(f"✅ 總共找到 {len(files)} 個檔案")
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'files': files,
                'count': len(files),
                'team_id': team_id,
                'prefix_used': s3_prefix,
                'debug': {
                    'bucket': TEAM_INFO_BUCKET,
                    'prefix': s3_prefix,
                    'timestamp': datetime.now().isoformat()
                }
            })
        }
        
    except Exception as e:
        logger.error(f"❌ 列出檔案失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '列出檔案失敗',
                'message': str(e),
                'team_id': team_id if 'team_id' in locals() else 'unknown',
                'timestamp': datetime.now().isoformat()
            })
        }

def handle_file_download(event: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
    """處理檔案下載 - 支援完整的 S3 key 或檔名"""
    try:
        # 支援多種參數取得方式
        path_params = event.get('pathParameters') or {}
        query_params = event.get('queryStringParameters') or {}
        path = event.get('path', '')
        
        # 嘗試從路徑參數或查詢參數取得 file_key
        file_key = (
            path_params.get('file_key') or 
            query_params.get('file_key') or 
            query_params.get('key') or 
            ''
        )
        
        # 如果還沒有找到 file_key，嘗試從 URL 路徑中解析
        if not file_key and '/download-team-file/' in path:
            # 從 /download-team-file/{file_key} 格式中解析
            parts = path.split('/download-team-file/')
            if len(parts) > 1 and parts[1]:
                file_key = urllib.parse.unquote(parts[1].strip('/'))
                logger.info(f"📥 從路徑解析 file_key: {file_key}")

        if not file_key:
            logger.warning("⚠️ 缺少檔案 key 參數")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': '缺少檔案 key',
                    'message': '請在路徑參數或查詢參數中提供 file_key',
                    'received_params': {
                        'path': path,
                        'pathParameters': path_params,
                        'queryStringParameters': query_params
                    }
                })
            }
        
        # 檢查 file_key 是否為完整的 S3 key 格式
        if not file_key.startswith(S3_FOLDER_PREFIX):
            # 如果不是完整格式，嘗試從 team_id 構建
            team_id = query_params.get('team_id') or query_params.get('teamId')
            if team_id:
                file_key = f"{S3_FOLDER_PREFIX}/{team_id}/{file_key}"
                logger.info(f"📥 構建完整 file_key: {file_key}")
        
        logger.info(f"📥 開始下載檔案: bucket={TEAM_INFO_BUCKET}, key={file_key}")
        
        # 檢查檔案是否存在
        try:
            s3.head_object(Bucket=TEAM_INFO_BUCKET, Key=file_key)
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                logger.warning(f"⚠️ 檔案不存在: {file_key}")
                return {
                    'statusCode': 404,
                    'headers': headers,
                    'body': json.dumps({
                        'error': '檔案不存在',
                        'key': file_key
                    })
                }
            else:
                raise e
        
        # 生成預簽名 URL 用於下載
        download_url = s3.generate_presigned_url(
            'get_object',
            Params={'Bucket': TEAM_INFO_BUCKET, 'Key': file_key},
            ExpiresIn=3600  # 1小時有效期
        )
        
        logger.info(f"✅ 生成下載 URL 成功: {file_key}")
        
        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'downloadUrl': download_url,
                'key': file_key,
                'expiresIn': 3600,
                'timestamp': datetime.now().isoformat()
            })
        }
        
    except Exception as e:
        logger.error(f"❌ 檔案下載失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '檔案下載失敗',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }

def handle_file_delete(event: Dict[str, Any], headers: Dict[str, str]) -> Dict[str, Any]:
    """處理檔案刪除"""
    try:
        logger.info("🗑️ 開始處理檔案刪除請求")
        
        try:
            body = json.loads(event.get('body', '{}'))
        except json.JSONDecodeError as e:
            logger.error(f"❌ JSON 解析失敗: {str(e)}")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': 'JSON 格式錯誤',
                    'message': str(e)
                })
            }
        
        s3_object_key = body.get('key')

        if not s3_object_key:
            logger.warning("⚠️ 請求體中缺少 'key'")
            return {
                'statusCode': 400,
                'headers': headers,
                'body': json.dumps({
                    'error': "請求體中缺少 'key'",
                    'received_body': body
                })
            }

        logger.info(f"🗑️ 刪除檔案: bucket={TEAM_INFO_BUCKET}, key={s3_object_key}")

        # 檢查檔案是否存在
        try:
            s3.head_object(Bucket=TEAM_INFO_BUCKET, Key=s3_object_key)
        except ClientError as e:
            if e.response['Error']['Code'] == 'NoSuchKey':
                logger.warning(f"⚠️ 檔案不存在: {s3_object_key}")
                return {
                    'statusCode': 404,
                    'headers': headers,
                    'body': json.dumps({
                        'error': '檔案不存在',
                        'key': s3_object_key
                    })
                }
            else:
                raise e

        # 刪除檔案
        s3.delete_object(Bucket=TEAM_INFO_BUCKET, Key=s3_object_key)

        logger.info(f"✅ 檔案刪除成功: {s3_object_key}")

        return {
            'statusCode': 200,
            'headers': headers,
            'body': json.dumps({
                'success': True,
                'message': '檔案刪除成功',
                'key': s3_object_key,
                'timestamp': datetime.now().isoformat()
            })
        }

    except Exception as e:
        logger.error(f"❌ 檔案刪除失敗: {str(e)}")
        import traceback
        logger.error(traceback.format_exc())
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({
                'error': '檔案刪除失敗',
                'message': str(e),
                'timestamp': datetime.now().isoformat()
            })
        }